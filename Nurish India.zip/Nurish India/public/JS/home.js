
document.addEventListener('DOMContentLoaded', function () {
    const images = document.querySelectorAll('.image img'); // Correct selector
    let currentIndex = 0;

    function showNextImage() {
        images[currentIndex].classList.remove('active');
        currentIndex = (currentIndex + 1) % images.length;
        images[currentIndex].classList.add('active');
    }

    // Start the slider
    setInterval(showNextImage, 3000); // Change image every 3 seconds
    // Toggle the dropdown menu
    document.querySelector('.menu-icon').addEventListener('click', function () {
        const dropdown = document.querySelector('.dropdown-content');
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    });
});
