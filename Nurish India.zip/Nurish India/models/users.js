const mongoose = require('mongoose');

const userSchema = new mongoose.schema({

    firstname: {
        type: String,
        require: true
    },
    lastname: {
        type: String,
        require: true
    },
    email: {
        type: String,
        require: true,
        match: [/.+@.+\..+/, "Please enter a valid email address"]
    },
    password: {
        type: String,
        require: true
    },
    gender: {
        type: String,
        enum: ["male", "female"]
    },
    address: String,
    phone: {
        type: String,
        mathc: [/^\d+$/, "Please enter a valid phone number"]

    },
    joinedTime: {
        type: Date,
        default: Date.now
    },
    role: {
        type: String,
        enum: ["admin", "donar", "agent"],
        require: true
    }


});
const User = mongoose.model("User", userSchema);
module.exports = User;
