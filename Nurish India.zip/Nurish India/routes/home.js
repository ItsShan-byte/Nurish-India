app.get('/home', (req, res) => {
    res.render('layout', { title: 'Home', content: 'home' });
});

app.get('/login', (req, res) => {
    res.render('layout', { title: 'login', content: 'login' });
});
