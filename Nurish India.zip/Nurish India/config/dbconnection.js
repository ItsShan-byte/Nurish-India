const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    const db = process.env.MONGODB_URI;
    await mongoose.connect(db, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useCreateIndex: true,    // Optional based on your Mongoose version
      useFindAndModify: false  // Optional based on your Mongoose version
    });
    console.log("MongoDB Connected...");
  } catch (err) {
    console.error("MongoDB connection error:", err);
    process.exit(1);  // Exit the process with failure
  }
};

module.exports = connectDB;
