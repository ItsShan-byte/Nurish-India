const LocalStragety = require ("passport-local").Strategy;
const bcrypt = require("bcryptjs");
const User = require("../models/users.js");

module.exports  = function (passport){

    passport.use(
        new LocalStragety(
            {usernameField:'email', passwordField:'password'},
            async (email,password,done) => {
                try {
                    //check if user exist
                    const user = await User.findOne({email:email});
                    if(!user) {
                        return done (null,false,{message:"the email is not registerd"});
                    }
                    //match password

                    const isMatch = await bcrypt.compare(password , user.password);
                    if(!isMatch){
                        return done(null,false,{message:"Incorrect password"})
                    }
                    //if password match , return the user

                    return done(null,user,{message:"Loggedin successfully"});
                }catch(err){
                    console.log(err);
                    return done(err);
                }
            }
        )
    );
    //serialize the user to store  user id and in session 

    passport.serialization((user,done)=>{
        done(null,user.id)

    });

    //deserialize the user to retrive the user from id stored in session
    passport.deserializeUser(async (id,done)=>{
        try{
            const user = await User.findById(id);
            done(null,user);

        }catch(err){
            done(err,null);
        }
    });
};

