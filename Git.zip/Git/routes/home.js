const express = require("express");
const router = express.Router();

router.get("/", (req,res) => {
	res.render("home/welcome");
});

router.get("/home/about-us", (req,res) => {
	res.render("home/aboutUs", { title: "About Us | Nurish India" });
});

router.get("/home/mission", (req,res) => {
	res.render("home/mission", { title: "Our mission | Nurish India" });
});

router.get("/home/contact-us", (req,res) => {
	res.render("home/contactUs", { title: "Contact us | Nurish India" });
});

router.get("/home/donation",(req,res) => {
	res.render("home/donation",{ title: "donation | Nurish India"});
})
module.exports = router;