const express = require('express');
const router = express.Router();
const Contact = require('../models/contactus.js'); // Ensure this path is correct

// Handle contact us form submission
router.post('/home/contactUs', async (req, res) => {
    const { name, email, phone, message } = req.body;

    try {
        const newContact = new Contact({ name, email, phone, message });
        await newContact.save();
        req.flash('success', 'Contact form submitted successfully!');
        res.redirect('/home/contactUs'); // Redirect to the contact form page or a success page
    } catch (error) {
        console.error('Error submitting contact form:', error);
        req.flash('error', 'An error occurred while submitting the form.');
        res.redirect('/home/contactUs'); // Redirect back to the contact form page on error
    }
});

module.exports = router;
